package com.example.api

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import android.util.Log

// --- طلبات واستجابات واجهة برمجة تطبيقات Gemini ---

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val responseMimeType: String? = null,
    val temperature: Float? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content?
)

// هيكلية أمر التحكم المستخرج من الذكاء الاصطناعي
@JsonClass(generateAdapter = true)
data class AnalyzedVoiceCommand(
    val action: String,          // TOGGLE_WIFI, SET_VOLUME, SAY_TEXT, SIMULATE_WORK, OPEN_FUN_ZONE, UNRECOGNIZED
    val actionPayload: String,   // القيمة المفتاحية المصاحبة للمتغير
    val speakResponse: String    // الرد الصوتي باللغة العربية
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiRetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    // محلل مخصص لتحليل النص المرتجع
    private val analyzedCommandAdapter = moshi.adapter(AnalyzedVoiceCommand::class.java)

    /**
     * استدعاء نموذج الذكاء الاصطناعي لتحليل الأمر الصوتي
     */
    suspend fun analyzeVoiceCommand(spokenText: String): AnalyzedVoiceCommand {
        // فحص المفتاح السري، إذا كان غير مفعّل أو فارغ نرجع محاكاة مباشرة لسرعة التشغيل
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e("GeminiRetrofitClient", "API Key is missing or default placeholder!")
            return simulateLocalSpeechAnalysis(spokenText)
        }

        val prompt = spokenText
        val systemInstructions = """
            أنت المساعد الذكي الصوتي للتحكم بالهاتف (تجربة صوتية). قم بتحليل النص الصوتي المدخل واستخراج نية التحكم بالهاتف وإرجاع رد بصيغة JSON تطابق الحقول التالية:
            - action: أحد الأوامر التالية فقط (TOGGLE_WIFI, SET_VOLUME, SAY_TEXT, SIMULATE_WORK, OPEN_FUN_ZONE, UNRECOGNIZED)
            - actionPayload: تعليق أو قيمة مصاحبة (مثال: "ON" أو "OFF" لـ TOGGLE_WIFI، "0" للوضع الصامت و "100" لأقصى صوت لـ SET_VOLUME، أو تفاصيل أخرى)
            - speakResponse: رد باللغة العربية بلهجة ودودة وممتازة تخبر المستخدم بما تنوي القيام به.
            
            قواعد الاستجابة:
            1. إذا كان النص يتعلق بالعمل، مثل ("أنا في العمل"، "ابدأ العمل"، "تفعيل وضع العمل"، "هدوء لو سمحت") ->
               action: SIMULATE_WORK, actionPayload: "WORK_ON", speakResponse: "تم تفعيل وضع العمل وتقليل إزعاج الجوال بنجاح."
            2. إذا كان النص يتعلق بالواي فاي، مثل ("طفي الواي فاي"، "شغل الشبكة"، "إيقاف الإنترنت") ->
               action: TOGGLE_WIFI, actionPayload: "OFF" أو "ON", speakResponse: "تم تنفيذ طلبك لتغيير حالة الواي فاي."
            3. إذا كان النص يتعلق بالصوت، مثل ("صامت"، "كتم"، "تخفيض الصوت"، "ارفع الصوت") ->
               action: SET_VOLUME, actionPayload: "0" أو "50" أو "100" حسب الطلب، speakResponse: "تم ضبط مستوى صوت الهاتف حسب رغبتك."
            4. إذا كان النص يتعلق بالملل أو التسلية، مثل ("أشعر بالملل"، "شغل وضع الترفيه"، "الوضع الترفيهي") ->
               action: OPEN_FUN_ZONE, actionPayload: "FUN_ON", speakResponse: "تم تشغيل لوحة الترفيه الصوتية لتخفيف الملل!"
            5. إذا كان غير معروف ->
               action: SAY_TEXT, actionPayload: "", speakResponse: "أنا هنا للاستماع إليك، هل ترغب في تخصيص هذا كأمر جديد في الإعدادات؟"
            
            يُرجى إرجاع JSON صالح وخام ولا تغلفه داخل وسوم الديكور مثل markdown ```json ```.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2f
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemInstructions)))
        )

        return try {
            val response = service.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                // محاولة فك الشفرة كـ JSON
                analyzedCommandAdapter.fromJson(jsonText) ?: simulateLocalSpeechAnalysis(spokenText)
            } else {
                simulateLocalSpeechAnalysis(spokenText)
            }
        } catch (e: Exception) {
            Log.e("GeminiRetrofitClient", "Failed to contact Gemini: ${e.message}")
            simulateLocalSpeechAnalysis(spokenText)
        }
    }

    /**
     * محاكي محلي سريع لتوفير تجربة مستقرة في وضع عدم الاتصال أو عدم إدخال مفتاح الذكاء الاصطناعي
     */
    fun simulateLocalSpeechAnalysis(text: String): AnalyzedVoiceCommand {
        val normalized = text.trim()
        return when {
            normalized.contains("عمل") || normalized.contains("المكتب") || normalized.contains("شغل وضع العمل") -> {
                AnalyzedVoiceCommand(
                    action = "SIMULATE_WORK",
                    actionPayload = "WORK_ON",
                    speakResponse = "حسناً، قمت بتنشيط وضع العمل وتفعيل الهدوء."
                )
            }
            normalized.contains("واي فاي") || normalized.contains("إنترنت") || normalized.contains("الشبكة") -> {
                val turnOn = normalized.contains("شغل") || normalized.contains("تفعيل")
                AnalyzedVoiceCommand(
                    action = "TOGGLE_WIFI",
                    actionPayload = if (turnOn) "ON" else "OFF",
                    speakResponse = if (turnOn) "تم تشغيل الواي فاي." else "تم إيقاف اتصال الواي فاي."
                )
            }
            normalized.contains("صامت") || normalized.contains("كتم") || normalized.contains("هدوء") -> {
                AnalyzedVoiceCommand(
                    action = "SET_VOLUME",
                    actionPayload = "0",
                    speakResponse = "تم كتم مستوى صوت الجهاز بنجاح."
                )
            }
            normalized.contains("ملل") || normalized.contains("تسلية") || normalized.contains("الملل") -> {
                AnalyzedVoiceCommand(
                    action = "OPEN_FUN_ZONE",
                    actionPayload = "FUN_ON",
                    speakResponse = "يبدو أنك تشعر بالملل! دعنا نشغل وضع الترفيه الصوتي والمحاكاة التفاعلية."
                )
            }
            normalized.contains("مساعدة") || normalized.contains("مرحبا") -> {
                AnalyzedVoiceCommand(
                    action = "SAY_TEXT",
                    actionPayload = "",
                    speakResponse = "أهلاً بك في تطبيق تجربة صوتية. يمكنك قول: تفعيل وضع العمل، طفي الواي فاي، أو الأشياء التي تشعرك بالملل!"
                )
            }
            else -> {
                AnalyzedVoiceCommand(
                    action = "SAY_TEXT",
                    actionPayload = "",
                    speakResponse = "سمعتك تقول: \"$text\". يمكنك الانتقال للتحكم في الأوامر وتخصيص هذا الأمر كإجراء فوري!"
                )
            }
        }
    }
}

package com.example.ui

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiRetrofitClient
import com.example.data.AppDatabase
import com.example.data.CustomCommand
import com.example.data.VoiceLog
import com.example.data.VoiceRepository
import com.example.service.MockPhoneController
import com.example.service.PhoneState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class VoiceViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = VoiceRepository(database.voiceCommandDao())
    val phoneController = MockPhoneController(application)

    // تدفق الأوامر واللوائح من قاعدة البيانات
    val customCommands: StateFlow<List<CustomCommand>> = repository.allCommands
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentLogs: StateFlow<List<VoiceLog>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val phoneState: StateFlow<PhoneState> = phoneController.phoneState

    // حالات التسجيل والواجهة
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _soundWaves = MutableStateFlow(List(12) { 0.1f })
    val soundWaves: StateFlow<List<Float>> = _soundWaves.asStateFlow()

    private val _speechBuffer = MutableStateFlow("")
    val speechBuffer: StateFlow<String> = _speechBuffer.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private var waveAnimatorJob: Job? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var recognizerIntent: Intent? = null

    init {
        // بذر أوامر افتراضية تفاعلية
        seedDefaultCommandsIfNeeded()
        setupSpeechRecognizer()
    }

    private fun seedDefaultCommandsIfNeeded() {
        viewModelScope.launch {
            customCommands.collect { list ->
                if (list.isEmpty()) {
                    val defaults = listOf(
                        CustomCommand(
                            triggerPhrase = "تفعيل وضع العمل",
                            actionType = "SIMULATE_WORK",
                            actionPayload = "WORK_ON",
                            isSystemDefault = true
                        ),
                        CustomCommand(
                            triggerPhrase = "إغلاق وضع العمل",
                            actionType = "SIMULATE_WORK",
                            actionPayload = "WORK_OFF",
                            isSystemDefault = true
                        ),
                        CustomCommand(
                            triggerPhrase = "طفي الواي فاي",
                            actionType = "TOGGLE_WIFI",
                            actionPayload = "OFF",
                            isSystemDefault = true
                        ),
                        CustomCommand(
                            triggerPhrase = "شغل الواي فاي",
                            actionType = "TOGGLE_WIFI",
                            actionPayload = "ON",
                            isSystemDefault = true
                        ),
                        CustomCommand(
                            triggerPhrase = "الوضع الصامت",
                            actionType = "SET_VOLUME",
                            actionPayload = "0",
                            isSystemDefault = true
                        ),
                        CustomCommand(
                            triggerPhrase = "وضع الترفيه",
                            actionType = "OPEN_FUN_ZONE",
                            actionPayload = "FUN_ON",
                            isSystemDefault = true
                        ),
                        CustomCommand(
                            triggerPhrase = "مساعدة صوتية",
                            actionType = "SAY_TEXT",
                            actionPayload = "مرحباً بك! أنا نظام التحكم الصوتي الذكي. قُل مثلاً: شغل الواي فاي، أو تفعيل وضع العمل لكتم الجوال.",
                            isSystemDefault = true
                        )
                    )
                    defaults.forEach { repository.insertCommand(it) }
                }
            }
        }
    }

    private fun setupSpeechRecognizer() {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                if (SpeechRecognizer.isRecognitionAvailable(getApplication())) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(getApplication()).apply {
                        setRecognitionListener(object : RecognitionListener {
                            override fun onReadyForSpeech(params: Bundle?) {
                                _speechBuffer.value = "تحدث الآن..."
                            }

                            override fun onBeginningOfSpeech() {
                                startWaveAnimation()
                            }

                            override fun onRmsChanged(rmsdB: Float) {
                                // ضبط حركة الأمواج بناءً على مستوى ديسيبل الصوت المسموع
                                updateWavesWithRms(rmsdB)
                            }

                            override fun onBufferReceived(buffer: ByteArray?) {}

                            override fun onEndOfSpeech() {
                                stopWaveAnimation()
                            }

                            override fun onError(error: Int) {
                                val message = when (error) {
                                    SpeechRecognizer.ERROR_AUDIO -> "خطأ في تسجيل الصوت"
                                    SpeechRecognizer.ERROR_CLIENT -> "مشكلة في الهاتف"
                                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "صلاحية الميكروفون مفقودة"
                                    SpeechRecognizer.ERROR_NETWORK -> "خطأ في الشبكة"
                                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "انتهت مهلة المزامنة"
                                    SpeechRecognizer.ERROR_NO_MATCH -> "لم يتم الكشف عن كلمة"
                                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "المعرّف مشغول"
                                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "انتهت مهلة التحدث"
                                    else -> "فشل التعرف على الصوت"
                                }
                                Log.e("VoiceViewModel", "Recognizer Error: $message (code: $error)")
                                _speechBuffer.value = ""
                                _isListening.value = false
                                stopWaveAnimation()
                            }

                            override fun onResults(results: Bundle?) {
                                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                val text = matches?.getOrNull(0)
                                if (!text.isNullOrBlank()) {
                                    handleUserSpeechInput(text)
                                } else {
                                    _speechBuffer.value = "لم يتم سماع أي كلمة بشكل واضح"
                                }
                                _isListening.value = false
                                stopWaveAnimation()
                            }

                            override fun onPartialResults(partialResults: Bundle?) {
                                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                val text = matches?.getOrNull(0)
                                if (!text.isNullOrBlank()) {
                                    _speechBuffer.value = text
                                }
                            }

                            override fun onEvent(eventType: Int, params: Bundle?) {}
                        })
                    }

                    recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA") // نبرز العربية كلغة افتراضية
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA")
                        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "ar-SA")
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    }
                }
            } catch (e: Exception) {
                Log.e("VoiceViewModel", "Failed to setup Native Speech Recognizer: ${e.message}")
            }
        }
    }

    /**
     * تشغيل التسجيل الصوتي الحقيقي
     */
    fun startListening() {
        phoneController.vibrate()
        _speechBuffer.value = "جاري تهيئة الميكروفون..."
        _isListening.value = true
        startWaveAnimation()

        viewModelScope.launch(Dispatchers.Main) {
            val recognizer = speechRecognizer
            val intent = recognizerIntent
            if (recognizer != null && intent != null) {
                try {
                    recognizer.startListening(intent)
                } catch (e: Exception) {
                    Log.e("VoiceViewModel", "Error starting listening client: ${e.message}")
                    // Fallback to manual prompt simulation if native crashes
                    simulateListeningDelay()
                }
            } else {
                // محاكاة سريعة في حال عدم توافق خدمات جوجل الصوتية داخل المحاكي المدمج في المتصفح
                simulateListeningDelay()
            }
        }
    }

    private fun simulateListeningDelay() {
        viewModelScope.launch {
            _speechBuffer.value = "استماع محاكي (اصدار التحدث بالطلب)..."
            delay(1500)
            _speechBuffer.value = "يمكنك كتابة طلبك أو الضغط على الأوامر الجاهزة لتجربتها مباشرة."
            _isListening.value = false
            stopWaveAnimation()
        }
    }

    /**
     * إيقاف التسجيل
     */
    fun stopListening() {
        _isListening.value = false
        stopWaveAnimation()
        viewModelScope.launch(Dispatchers.Main) {
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.e("VoiceViewModel", "Error stopping recognizer: ${e.message}")
            }
        }
    }

    /**
     * معالجة نص الأمر المسموع صوتياً أو المدخل يدوياً
     */
    fun handleUserSpeechInput(text: String) {
        if (text.isBlank() || _isProcessing.value) return
        _isProcessing.value = true
        _speechBuffer.value = text

        viewModelScope.launch(Dispatchers.IO) {
            phoneController.vibrate()
            val normalized = text.trim()
            var executedAction = "UNRECOGNIZED"
            var executedPayload = ""
            var speakMsg = ""
            var matchedCommand: CustomCommand? = null

            // ب1: محاولة تصنيف الطلب بناءً على الأوامر الصوتية المخصصة في قاعدة البيانات
            val currentCommands = customCommands.value
            val match = currentCommands.firstOrNull { cmd ->
                cmd.isActive && normalized.contains(cmd.triggerPhrase.trim(), ignoreCase = true)
            }

            if (match != null) {
                matchedCommand = match
                executedAction = match.actionType
                executedPayload = match.actionPayload
                speakMsg = when (match.actionType) {
                    "SAY_TEXT" -> match.actionPayload
                    "SIMULATE_WORK" -> if (match.actionPayload == "WORK_ON") "تم تشغيل وضع العمل وكتم أصوات الجوال." else "تم تعطيل وضع العمل واستعادة رنات الهاتف."
                    "TOGGLE_WIFI" -> if (match.actionPayload == "ON") "تم تشغيل الواي فاي." else "تم إطفاء الواي فاي كلياً."
                    "SET_VOLUME" -> "تم ضبط مستوى الصوت على ${match.actionPayload}."
                    "OPEN_FUN_ZONE" -> "وضعية الترفيه جاهزة للعمل، ما الذي تود الاستماع إليه؟"
                    else -> match.actionPayload
                }

                // زيادة العداد المطابق للاحصائيات
                repository.updateCommand(match.copy(matchCount = match.matchCount + 1))
            } else {
                // ب2: الاتصال بذكاء جيمي الاصطناعي لحساب الأمر وتسهيل التفسير
                val aiCommand = GeminiRetrofitClient.analyzeVoiceCommand(normalized)
                executedAction = aiCommand.action
                executedPayload = aiCommand.actionPayload
                speakMsg = aiCommand.speakResponse
            }

            // تنفيذ القرار محلياً بالهاتف
            withContext(Dispatchers.Main) {
                when (executedAction) {
                    "TOGGLE_WIFI" -> {
                        val enable = executedPayload.uppercase(Locale.ROOT) == "ON" || executedPayload == "1"
                        phoneController.toggleWifi(enable)
                    }
                    "SET_VOLUME" -> {
                        val vol = executedPayload.toIntOrNull() ?: 50
                        phoneController.setSystemVolume(vol)
                    }
                    "SIMULATE_WORK" -> {
                        val active = executedPayload.uppercase(Locale.ROOT) != "WORK_OFF" && executedPayload != "0"
                        phoneController.setWorkMode(active)
                    }
                    "OPEN_FUN_ZONE" -> {
                        val active = executedPayload.uppercase(Locale.ROOT) != "FUN_OFF" && executedPayload != "0"
                        phoneController.setFunMode(active)
                        if (active) {
                            phoneController.setWorkMode(false) // إغلاق العمل عند تفعيل الترفيه بالتناوب
                        }
                    }
                }
                phoneController.speak(speakMsg)
            }

            // تسجيل السجل بقاعدة البيانات
            repository.insertLog(
                VoiceLog(
                    inputText = normalized,
                    parsedIntent = "$executedAction ($executedPayload)",
                    responseMessage = speakMsg,
                    triggerId = matchedCommand?.id,
                    success = executedAction != "UNRECOGNIZED"
                )
            )

            _isProcessing.value = false
        }
    }

    // إدارة حركة الميكروفون الجمالية
    private fun startWaveAnimation() {
        waveAnimatorJob?.cancel()
        waveAnimatorJob = viewModelScope.launch {
            while (_isListening.value) {
                _soundWaves.value = List(12) { kotlin.random.Random.nextFloat() * (1.0f - 0.2f) + 0.2f }
                delay(80)
            }
            _soundWaves.value = List(12) { 0.1f } // إرجاعها لشخص مسطح
        }
    }

    private fun updateWavesWithRms(rmsdB: Float) {
        val amp = ((rmsdB + 2f) / 12f).coerceIn(0.1f, 1.0f)
        _soundWaves.value = List(12) { 
            val randFactor = kotlin.random.Random.nextFloat() * (1.1f - 0.6f) + 0.6f
            (amp * randFactor).coerceIn(0.1f, 1.0f)
        }
    }

    private fun stopWaveAnimation() {
        waveAnimatorJob?.cancel()
        _soundWaves.value = List(12) { 0.1f }
    }

    // إدارة العمليات على الأوامر الصوتية بالواجهة
    fun addNewCustomCommand(phrase: String, action: String, payload: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertCommand(
                CustomCommand(
                    triggerPhrase = phrase.trim(),
                    actionType = action,
                    actionPayload = payload.trim()
                )
            )
        }
    }

    fun deleteCustomCommand(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCommandById(id)
        }
    }

    fun clearLogHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearLogs()
        }
    }

    override fun onCleared() {
        super.onCleared()
        phoneController.release()
        speechRecognizer?.destroy()
    }
}

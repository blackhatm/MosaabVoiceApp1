package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Sophisticated Dark Color Palette
val SophisticatedBackground = Color(0xFF1A1C1E)
val SophisticatedSurface = Color(0xFF2F3033)
val SophisticatedCard = Color(0xFF1D1B20)
val SophisticatedOnBackground = Color(0xFFE2E2E6)
val SophisticatedOnSurface = Color(0xFFE2E2E6)
val SophisticatedSecondaryText = Color(0xFFC4C6CF)
val SophisticatedPrimary = Color(0xFFD0BCFF)
val SophisticatedPrimaryContainer = Color(0xFF381E72)
val SophisticatedOnPrimaryContainer = Color(0xFFE8DEF8)
val SophisticatedOutline = Color(0xFF49454F)
val SophisticatedNavigationActive = Color(0xFFE8DEF8)

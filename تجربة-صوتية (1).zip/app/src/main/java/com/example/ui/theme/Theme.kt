package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = SophisticatedPrimary,
  secondary = SophisticatedSecondaryText,
  tertiary = SophisticatedNavigationActive,
  background = SophisticatedBackground,
  surface = SophisticatedSurface,
  onBackground = SophisticatedOnBackground,
  onSurface = SophisticatedOnSurface,
  primaryContainer = SophisticatedPrimaryContainer,
  onPrimaryContainer = SophisticatedOnPrimaryContainer,
  outline = SophisticatedOutline
)

private val LightColorScheme = darkColorScheme( // Force dark representation or use custom dark scheme to match the theme
  primary = SophisticatedPrimary,
  secondary = SophisticatedSecondaryText,
  tertiary = SophisticatedNavigationActive,
  background = SophisticatedBackground,
  surface = SophisticatedSurface,
  onBackground = SophisticatedOnBackground,
  onSurface = SophisticatedOnSurface,
  primaryContainer = SophisticatedPrimaryContainer,
  onPrimaryContainer = SophisticatedOnPrimaryContainer,
  outline = SophisticatedOutline
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme for Sophisticated Dark aesthetic
  dynamicColor: Boolean = false, // Keep theme colors consistent
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

package com.example.service

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

// حالة الهاتف المحاكية والحقيقية معاً
data class PhoneState(
    val isWifiEnabled: Boolean = true,
    val volumeLevel: Int = 50, // نسبة مئوية 0-100
    val isWorkModeActive: Boolean = false,
    val isFunModeActive: Boolean = false,
    val lastSpokenResponse: String = "جاهز لتلقي الأوامر",
    val systemStatusText: String = "متصل وجاهز"
)

class MockPhoneController(private val context: Context) : TextToSpeech.OnInitListener {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _phoneState = MutableStateFlow(
        PhoneState(
            volumeLevel = getSystemVolumePercent()
        )
    )
    val phoneState: StateFlow<PhoneState> = _phoneState.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e("MockPhoneController", "TTS Initialization failed: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ar"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("MockPhoneController", "Arabic language for TTS is not supported!")
                // المحاولة باللغة الافتراضية
                tts?.setLanguage(Locale.getDefault())
            }
            isTtsInitialized = true
        } else {
            Log.e("MockPhoneController", "TTS Init Failed status code: $status")
        }
    }

    /**
     * نطق النصوص بالصوت العربي الحقيقي باستخدام TTS للهاتف
     */
    fun speak(text: String) {
        _phoneState.value = _phoneState.value.copy(lastSpokenResponse = text)
        if (isTtsInitialized && tts != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voice_control_utterance_id")
                } else {
                    @Suppress("DEPRECATION")
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null)
                }
            } catch (e: Exception) {
                Log.e("MockPhoneController", "TTS Speak exception: ${e.message}")
            }
        } else {
            Log.w("MockPhoneController", "TTS not initialized, print text only: $text")
        }
    }

    /**
     * تفعيل الاهتزاز لتنبيه المستخدم عند استماع الأمر الصوتي أو تنفيذه
     */
    fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                val vibrator = vibratorManager.defaultVibrator
                vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator.vibrate(100)
            }
        } catch (e: SecurityException) {
            Log.w("MockPhoneController", "Vibrate permission missing or failed: ${e.message}")
        } catch (e: Exception) {
            Log.w("MockPhoneController", "Vibrate failed: ${e.message}")
        }
    }

    /**
     * تشغيل أو إغلاق الواي فاي المحاكي
     */
    fun toggleWifi(enable: Boolean) {
        _phoneState.value = _phoneState.value.copy(
            isWifiEnabled = enable,
            systemStatusText = if (enable) "الواي فاي مفعّل" else "تم إيقاف تشغيل الواي فاي"
        )
    }

    /**
     * تغيير وضع مستوى صوت النظام ومحاكاته
     */
    fun setSystemVolume(percent: Int) {
        try {
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val indexValue = (maxVolume * (percent / 100.0)).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, indexValue, AudioManager.FLAG_SHOW_UI)
        } catch (e: Exception) {
            Log.e("MockPhoneController", "Failed to change system volume: ${e.message}")
        }

        _phoneState.value = _phoneState.value.copy(
            volumeLevel = percent,
            systemStatusText = "مستوى الصوت: %$percent"
        )
    }

    /**
     * تفعيل أو إلغاء وضع العمل
     */
    fun setWorkMode(active: Boolean) {
        _phoneState.value = _phoneState.value.copy(
            isWorkModeActive = active,
            // كتم الصوت تلقائياً عند تفعيل وضع العمل لتقليل الإزعاج
            volumeLevel = if (active) 0 else 60,
            systemStatusText = if (active) "وضع العمل نشط (الهاتف صامت)" else "تم إنهاء وضع العمل"
        )
        if (active) {
            setSystemVolume(0)
        } else {
            setSystemVolume(60)
        }
    }

    /**
     * تفعيل وضع التسلية
     */
    fun setFunMode(active: Boolean) {
        _phoneState.value = _phoneState.value.copy(
            isFunModeActive = active,
            // رفع الصوت قليلاً للترفيه الصوتي
            volumeLevel = if (active) 75 else _phoneState.value.volumeLevel,
            systemStatusText = if (active) "وضع الترفيه نشط!" else "تم إيقاف وضع الترفيه"
        )
        if (active) {
            setSystemVolume(75)
        }
    }

    private fun getSystemVolumePercent(): Int {
        return try {
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (max > 0) (current * 100) / max else 50
        } catch (e: Exception) {
            50
        }
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            Log.e("MockPhoneController", "Shutdown failed: ${e.message}")
        }
    }
}

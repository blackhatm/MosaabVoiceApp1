package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custom_commands")
data class CustomCommand(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val triggerPhrase: String,      // الكلمة المفتاحية أو العبارة (مثال: "تفعيل وضع العمل")
    val actionType: String,         // نوع الحركة: e.g. "TOGGLE_WIFI", "SET_VOLUME", "SAY_TEXT", "OPEN_APP", "SIMULATE_WORK"
    val actionPayload: String,      // القيمة المصاحبة للطلب (مثال: "تم تفعيل وضع العمل وخفض الصوت")
    val isActive: Boolean = true,
    val isSystemDefault: Boolean = false,
    val matchCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "voice_logs")
data class VoiceLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val inputText: String,          // العبارة الصوتية المسموعة
    val parsedIntent: String,       // الأمر الذي تم كشفه ميكانيكياً أو بالذكاء الاصطناعي
    val responseMessage: String,    // رد المساعد الصوتي المنطوق
    val triggerId: Int? = null,     // معرّف الأمر المخصص في حال حدوث تطابق
    val timestamp: Long = System.currentTimeMillis(),
    val success: Boolean = true
)

package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceCommandDao {
    @Query("SELECT * FROM custom_commands ORDER BY isSystemDefault DESC, triggerPhrase ASC")
    fun getAllCommands(): Flow<List<CustomCommand>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommand(command: CustomCommand)

    @Update
    suspend fun updateCommand(command: CustomCommand)

    @Query("DELETE FROM custom_commands WHERE id = :id")
    suspend fun deleteCommandById(id: Int)

    @Query("SELECT * FROM voice_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentLogs(): Flow<List<VoiceLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: VoiceLog)

    @Query("DELETE FROM voice_logs")
    suspend fun clearLogs()
}

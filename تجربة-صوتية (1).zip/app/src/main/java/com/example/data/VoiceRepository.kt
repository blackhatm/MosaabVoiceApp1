package com.example.data

import kotlinx.coroutines.flow.Flow

class VoiceRepository(private val dao: VoiceCommandDao) {
    val allCommands: Flow<List<CustomCommand>> = dao.getAllCommands()
    val recentLogs: Flow<List<VoiceLog>> = dao.getRecentLogs()

    suspend fun insertCommand(command: CustomCommand) {
        dao.insertCommand(command)
    }

    suspend fun updateCommand(command: CustomCommand) {
        dao.updateCommand(command)
    }

    suspend fun deleteCommandById(id: Int) {
        dao.deleteCommandById(id)
    }

    suspend fun insertLog(log: VoiceLog) {
        dao.insertLog(log)
    }

    suspend fun clearLogs() {
        dao.clearLogs()
    }
}

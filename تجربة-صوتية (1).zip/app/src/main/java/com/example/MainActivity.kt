package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CustomCommand
import com.example.data.VoiceLog
import com.example.ui.VoiceViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: VoiceViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        VoiceExperienceApp(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceExperienceApp(
    viewModel: VoiceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val phoneState by viewModel.phoneState.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val speechBuffer by viewModel.speechBuffer.collectAsStateWithLifecycle()
    val soundWaves by viewModel.soundWaves.collectAsStateWithLifecycle()
    val customCommands by viewModel.customCommands.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentLogs.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf("dashboard") } // dashboard, commands, logs
    var showAddDialog by remember { mutableStateOf(false) }
    var micPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        micPermissionGranted = isGranted
        if (isGranted) {
            Toast.makeText(context, "تم تفعيل صلاحية الميكروفون بنجاح", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                context,
                "الصلاحية مطلوبة للتعرف الحقيقي على الأوامر الصوتية",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // لولب الرسم النبضي اللانهائي حول زر الاستماع
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // الألوان المستوحاة من الطابع الفخم الداكن (Sophisticated Dark)
    val spaceDark = SophisticatedBackground
    val cardBackground = SophisticatedSurface
    val accentNeonCyan = SophisticatedPrimary
    val accentGreen = Color(0xFF34D399)
    val accentOrange = Color(0xFFF87171)
    val textMuted = SophisticatedSecondaryText

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(spaceDark, Color(0xFF151719))
                )
            )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // --- عنوان التطبيق والهوية البصرية الساحر ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(SophisticatedPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = SophisticatedPrimaryContainer,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "تجربة صوتية",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = SophisticatedOnBackground
                        )
                        Text(
                            text = "تحكم ذكي بالهاتف طوال الوقت",
                            fontSize = 11.sp,
                            color = textMuted,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // عرض مؤشر حالة الذكاء الاصطناعي بالتصميم الفخم
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SophisticatedCard,
                    border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f)),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "الذكاء الاصطناعي",
                            tint = accentNeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Gemini 3.5 Active",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // --- التبويبات الفاخرة ---
            ScrollableTabRow(
                selectedTabIndex = when (activeTab) {
                    "dashboard" -> 0
                    "commands" -> 1
                    else -> 2
                },
                edgePadding = 16.dp,
                containerColor = Color.Transparent,
                contentColor = accentNeonCyan,
                indicator = { tabPositions ->
                    if (tabPositions.isNotEmpty()) {
                        val activeIndex = when (activeTab) {
                            "dashboard" -> 0
                            "commands" -> 1
                            else -> 2
                        }
                        Box(
                            modifier = Modifier
                                .tabIndicatorOffset(tabPositions[activeIndex])
                                .height(3.dp)
                                .background(
                                    color = SophisticatedPrimary,
                                    shape = RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)
                                )
                        )
                    }
                },
                divider = {}
            ) {
                Tab(
                    selected = activeTab == "dashboard",
                    onClick = { activeTab = "dashboard" },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.KeyboardVoice,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("الرئيسية", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    },
                    selectedContentColor = Color.White,
                    unselectedContentColor = textMuted
                )
                Tab(
                    selected = activeTab == "commands",
                    onClick = { activeTab = "commands" },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SettingsVoice,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("أوامري المخصصة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    },
                    selectedContentColor = Color.White,
                    unselectedContentColor = textMuted
                )
                Tab(
                    selected = activeTab == "logs",
                    onClick = { activeTab = "logs" },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("سجل الأحداث", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    },
                    selectedContentColor = Color.White,
                    unselectedContentColor = textMuted
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // --- محتوى الصفحة النشطة ---
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (activeTab) {
                    "dashboard" -> {
                        DashboardScreen(
                            viewModel = viewModel,
                            phoneState = phoneState,
                            isListening = isListening,
                            isProcessing = isProcessing,
                            speechBuffer = speechBuffer,
                            soundWaves = soundWaves,
                            pulseScale = pulseScale,
                            micPermissionGranted = micPermissionGranted,
                            onPermissionRequest = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                        )
                    }
                    "commands" -> {
                        CommandsScreen(
                            commands = customCommands,
                            onDelete = { viewModel.deleteCustomCommand(it) },
                            onAddClick = { showAddDialog = true }
                        )
                    }
                    "logs" -> {
                        LogsScreen(
                            logs = recentLogs,
                            onClearLogs = { viewModel.clearLogHistory() }
                        )
                    }
                }
            }
        }

        // الحوار الطافي لإضافة أمر جديد مخصص
        if (showAddDialog) {
            AddCommandDialog(
                onDismiss = { showAddDialog = false },
                onAdd = { phrase, action, payload ->
                    viewModel.addNewCustomCommand(phrase, action, payload)
                    showAddDialog = false
                    Toast.makeText(context, "تم حفظ الأمر الجديد بنجاح", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun DashboardScreen(
    viewModel: VoiceViewModel,
    phoneState: com.example.service.PhoneState,
    isListening: Boolean,
    isProcessing: Boolean,
    speechBuffer: String,
    soundWaves: List<Float>,
    pulseScale: Float,
    micPermissionGranted: Boolean,
    onPermissionRequest: () -> Unit
) {
    val context = LocalContext.current
    var manualTextInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. لوحة المايك المحاكي والبث الفوري للموجات الصوتية
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isListening) "جاري الاستماع للطلبات..." else "اضغط للتحدث والتحكم في الهاتف",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isListening) SophisticatedPrimary else Color.White,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // تأثير النبضات الجمالية حول زر الميكروفون باللون اللافندر الفاخر
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(160.dp)
                    ) {
                        if (isListening) {
                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(SophisticatedPrimary.copy(alpha = 0.15f))
                            )
                            Box(
                                modifier = Modifier
                                    .size(130.dp)
                                    .scale(pulseScale * 0.9f)
                                    .clip(CircleShape)
                                    .background(SophisticatedPrimary.copy(alpha = 0.08f))
                            )
                        }

                        IconButton(
                            onClick = {
                                if (!micPermissionGranted) {
                                    onPermissionRequest()
                                } else {
                                    if (isListening) {
                                        viewModel.stopListening()
                                    } else {
                                        viewModel.startListening()
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(90.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.radialGradient(
                                        colors = if (isListening) {
                                            listOf(SophisticatedPrimary, SophisticatedPrimaryContainer)
                                        } else {
                                            listOf(SophisticatedPrimaryContainer, SophisticatedCard)
                                        }
                                    )
                                )
                                .testTag("listening_voice_button")
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                                contentDescription = "استماع مباشر",
                                tint = if (isListening) SophisticatedPrimaryContainer else SophisticatedPrimary,
                                modifier = Modifier.size(42.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // تمثيل الموجات الصوتية بشكل رقيق فائق الجودة
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .padding(horizontal = 40.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        soundWaves.forEachIndexed { index, weight ->
                            val waveHeight = 4.dp + (32.dp * weight)
                            val gradient = Brush.verticalGradient(
                                colors = listOf(SophisticatedPrimary, SophisticatedNavigationActive)
                            )
                            Box(
                                modifier = Modifier
                                    .width(6.dp)
                                    .height(waveHeight)
                                    .clip(CircleShape)
                                    .background(brush = gradient)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // فقاعة الاستجابة الصوتية المسموعة أو المكتوبة بالتصميم المطور
                    if (speechBuffer.isNotEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SophisticatedCard,
                            border = BorderStroke(1.dp, SophisticatedOutline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QuestionAnswer,
                                    contentDescription = null,
                                    tint = SophisticatedPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = speechBuffer,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isProcessing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = SophisticatedPrimary,
                                        strokeWidth = 2.dp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. لوحة التحكم بحالات الهاتف اللحظية والمحاكاة التفاعلية بالتصميم الفخم
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "مؤشرات وحالات لوحة الهاتف",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // حاله الواي فاي ووضع العمل في صفوف سريعة المراجعة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // كرت الواي فاي
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.phoneController.toggleWifi(!phoneState.isWifiEnabled) },
                            shape = RoundedCornerShape(16.dp),
                            color = if (phoneState.isWifiEnabled) SophisticatedPrimaryContainer.copy(alpha = 0.4f) else SophisticatedCard,
                            border = BorderStroke(1.dp, if (phoneState.isWifiEnabled) SophisticatedPrimary else SophisticatedOutline)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Icon(
                                    imageVector = if (phoneState.isWifiEnabled) Icons.Default.Wifi else Icons.Default.WifiOff,
                                    contentDescription = null,
                                    tint = if (phoneState.isWifiEnabled) SophisticatedPrimary else SophisticatedSecondaryText
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("الواي فاي", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    if (phoneState.isWifiEnabled) "مستقر ومفعّل" else "غير متصل",
                                    color = SophisticatedSecondaryText,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // كرت وضع العمل المخصص
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.phoneController.setWorkMode(!phoneState.isWorkModeActive) },
                            shape = RoundedCornerShape(16.dp),
                            color = if (phoneState.isWorkModeActive) SophisticatedPrimaryContainer.copy(alpha = 0.4f) else SophisticatedCard,
                            border = BorderStroke(1.dp, if (phoneState.isWorkModeActive) SophisticatedPrimary else SophisticatedOutline)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Icon(
                                    imageVector = Icons.Default.WorkOutline,
                                    contentDescription = null,
                                    tint = if (phoneState.isWorkModeActive) SophisticatedPrimary else SophisticatedSecondaryText
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("وضع العمل", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    if (phoneState.isWorkModeActive) "صامت وجاري المحاكاة" else "غير نشط",
                                    color = SophisticatedSecondaryText,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // مستوى الصوت ومؤشر التمثيل
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = SophisticatedCard,
                        border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (phoneState.volumeLevel == 0) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                        contentDescription = null,
                                        tint = if (phoneState.volumeLevel > 0) SophisticatedPrimary else Color(0xFFF87171),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("مستوى صوت الهاتف", color = Color.White, fontSize = 11.sp)
                                }
                                Text("%${phoneState.volumeLevel}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { phoneState.volumeLevel / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = if (phoneState.volumeLevel > 0) SophisticatedPrimary else Color(0xFF64748B),
                                trackColor = SophisticatedSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // كبسولة معلومات النظام الأخيرة المنطوقة
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(SophisticatedCard)
                            .border(1.dp, SophisticatedOutline.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = Color(0xFFFBBF24),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "صوت الهاتف ينطق الآن: ",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = phoneState.lastSpokenResponse,
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 3. لوحة الأزرار السريعة للمحاكاة الفورية للأوامر والمساعدة باللمس بالتصميم الفاخر
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "محاكاة صوتية سريعة بنقرة واحدة",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "يتيح هذا القسم سرعة التشغيل واختبار الذكاء للأوامر الصوتية بكبسة مباشرة.",
                        fontSize = 11.sp,
                        color = SophisticatedSecondaryText,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // صف أول للاختبارات السريعة بتصميم المربعات الأنيقة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.handleUserSpeechInput("تفعيل وضع العمل") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SophisticatedCard),
                            border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Text("وضع العمل (صامت)", fontSize = 11.sp, color = SophisticatedPrimary, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.handleUserSpeechInput("إيقاف تشغيل الواي فاي") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SophisticatedCard),
                            border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Text("إيقاف الواي فاي", fontSize = 11.sp, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // صف ثاني للاختبارات السريعة بالتصميم الأنيق
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.handleUserSpeechInput("شغل الواي فاي") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SophisticatedCard),
                            border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Text("تشغيل الواي فاي", fontSize = 11.sp, color = Color.White)
                        }

                        Button(
                            onClick = { viewModel.handleUserSpeechInput("أشعر بالملل الشديد") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SophisticatedCard),
                            border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Text("وضع الملل والتسلية", fontSize = 11.sp, color = SophisticatedPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 4. كتابة يدوية في حال تعطل الفونكشينالي الحقيقية ومحاكاة الأمر المكتوب
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = SophisticatedSurface),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "جرب قول أمر بصيغة النص",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = manualTextInput,
                            onValueChange = { manualTextInput = it },
                            placeholder = { Text("مثال: طفي الواي فاي، هل تفعيل الصامت جاهز؟", fontSize = 12.sp, color = SophisticatedSecondaryText) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("manual_voice_input_field"),
                            maxLines = 1,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = SophisticatedPrimary,
                                unfocusedBorderColor = SophisticatedOutline,
                                focusedPlaceholderColor = SophisticatedSecondaryText,
                                unfocusedPlaceholderColor = SophisticatedSecondaryText
                             ),
                            shape = RoundedCornerShape(16.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                if (manualTextInput.isNotBlank()) {
                                    viewModel.handleUserSpeechInput(manualTextInput)
                                    manualTextInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(SophisticatedPrimary)
                                .testTag("manual_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "أرسل",
                                tint = SophisticatedPrimaryContainer
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun CommandsScreen(
    commands: List<CustomCommand>,
    onDelete: (Int) -> Unit,
    onAddClick: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "تخصيص الأوامر الصوتية",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${commands.size} أمر متاح حالياً للتشغيل",
                        fontSize = 12.sp,
                        color = SophisticatedSecondaryText
                    )
                }

                Button(
                    onClick = onAddClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SophisticatedPrimary,
                        contentColor = SophisticatedPrimaryContainer
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("add_command_trigger_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "أضف",
                        tint = SophisticatedPrimaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("أضف أمر", fontSize = 12.sp, color = SophisticatedPrimaryContainer, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (commands.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SettingsVoice,
                            contentDescription = null,
                            tint = SophisticatedOutline,
                            modifier = Modifier.size(60.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا توجد أوامر مخصصة بعد",
                            color = SophisticatedSecondaryText,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "تستطيع الضغط على 'أضف أمر' لتحديد عباراتك المفضلة.",
                            color = SophisticatedSecondaryText.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(commands) { cmd ->
                        CommandItem(command = cmd, onDelete = { onDelete(cmd.id) })
                    }
                    item {
                        Spacer(modifier = Modifier.height(30.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun CommandItem(
    command: CustomCommand,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SophisticatedCard),
        border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (command.isSystemDefault) SophisticatedPrimaryContainer else SophisticatedSurface,
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        Text(
                            text = if (command.isSystemDefault) "افتراضي" else "مخصص",
                            color = if (command.isSystemDefault) SophisticatedPrimary else SophisticatedSecondaryText,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "عندما أقول: \"${command.triggerPhrase}\"",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (command.actionType) {
                            "TOGGLE_WIFI" -> Icons.Default.Wifi
                            "SET_VOLUME" -> Icons.Default.VolumeUp
                            "SIMULATE_WORK" -> Icons.Default.WorkOutline
                            "OPEN_FUN_ZONE" -> Icons.Default.Celebration
                            else -> Icons.Default.Campaign
                        },
                        contentDescription = null,
                        tint = SophisticatedPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الإجراء: ${getReadableActionName(command.actionType)}",
                        fontSize = 11.sp,
                        color = SophisticatedSecondaryText
                    )
                }

                if (command.matchCount > 0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "تم التنشيط: ${command.matchCount} مرات",
                        fontSize = 10.sp,
                        color = SophisticatedPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // خيار الحذف إذا كان مخصصاً
            if (!command.isSystemDefault) {
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEF4444).copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف الأمر",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun LogsScreen(
    logs: List<VoiceLog>,
    onClearLogs: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "سجل العمليات والأحداث",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "يعرض أداء المساعد للتحليل المباشر للأفعال",
                    fontSize = 11.sp,
                    color = SophisticatedSecondaryText
                )
            }

            if (logs.isNotEmpty()) {
                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier
                        .border(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .height(32.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DeleteForever,
                            contentDescription = "مسح الكل",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مسح الكل", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.HistoryToggleOff,
                        contentDescription = null,
                        tint = SophisticatedOutline,
                        modifier = Modifier.size(60.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "لا توجد سجلات منشطة",
                        color = SophisticatedSecondaryText,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "جرب التحدث بطلبك الصوتي لتشاهد التحليل فورا هنا.",
                        color = SophisticatedSecondaryText.copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(logs) { log ->
                    LogItem(log = log, timeText = sdf.format(Date(log.timestamp)))
                }
                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}

@Composable
fun LogItem(log: VoiceLog, timeText: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SophisticatedCard),
        border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (log.success) Color(0xFF34D399) else Color(0xFFEF4444))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الصوت المنطوق: \"${log.inputText}\"",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Text(
                    text = timeText,
                    fontSize = 10.sp,
                    color = SophisticatedSecondaryText
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // القرار المنفذ
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.DirectionsRun,
                    contentDescription = null,
                    tint = SophisticatedPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "الإجراء المفسر: ${log.parsedIntent}",
                    fontSize = 11.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // الرد المنطوق
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = SophisticatedPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "رد الهاتف: ${log.responseMessage}",
                    fontSize = 11.sp,
                    color = SophisticatedSecondaryText
                )
            }
        }
    }
}

@Composable
fun AddCommandDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String) -> Unit
) {
    var triggerPhrase by remember { mutableStateOf("") }
    var selectedAction by remember { mutableStateOf("SAY_TEXT") }
    var actionPayload by remember { mutableStateOf("") }

    val docActions = listOf(
        Pair("SAY_TEXT", "تحدث بعبارة مخصصة"),
        Pair("SIMULATE_WORK", "التحكم بوضع العمل (OFF / ON)"),
        Pair("TOGGLE_WIFI", "تغيير الإنترنت والواي فاي (OFF / ON)"),
        Pair("SET_VOLUME", "حجم الصوت (0 - 100)"),
        Pair("OPEN_FUN_ZONE", "تفعيل وضعية التسلية")
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = SophisticatedCard,
            border = BorderStroke(1.dp, SophisticatedOutline.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "إضافة أمر صوتي مخصص",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(14.dp))

                // العبارة الصوتية المفرزة
                Text(
                    text = "العبارة الصوتية المسموعة (الزناد):",
                    fontSize = 11.sp,
                    color = SophisticatedPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = triggerPhrase,
                    onValueChange = { triggerPhrase = it },
                    placeholder = { Text("مثال: هدوء بالمكتب", fontSize = 12.sp, color = SophisticatedSecondaryText) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_trigger_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = SophisticatedPrimary,
                        unfocusedBorderColor = SophisticatedOutline,
                        focusedPlaceholderColor = SophisticatedSecondaryText,
                        unfocusedPlaceholderColor = SophisticatedSecondaryText
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // اختيار نوع الحركة
                Text(
                    text = "نوع إجراء التحكم بالهاتف:",
                    fontSize = 11.sp,
                    color = SophisticatedPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    docActions.forEach { action ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedAction == action.first) SophisticatedPrimary.copy(alpha = 0.15f) else Color.Transparent)
                                .clickable {
                                    selectedAction = action.first
                                    // وضع قيم افتراضية ذكية للمعايير لتسهيل التشغيل
                                    actionPayload = when (action.first) {
                                        "TOGGLE_WIFI" -> "OFF"
                                        "SET_VOLUME" -> "0"
                                        "SIMULATE_WORK" -> "WORK_ON"
                                        "OPEN_FUN_ZONE" -> "FUN_ON"
                                        else -> "مرحبًا بك!"
                                    }
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedAction == action.first,
                                onClick = {
                                    selectedAction = action.first
                                    actionPayload = when (action.first) {
                                        "TOGGLE_WIFI" -> "OFF"
                                        "SET_VOLUME" -> "0"
                                        "SIMULATE_WORK" -> "WORK_ON"
                                        "OPEN_FUN_ZONE" -> "FUN_ON"
                                        else -> "مرحبًا بك!"
                                    }
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = SophisticatedPrimary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = action.second, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // معيار الإجراء المطلوب
                Text(
                    text = "محتوى الرد / قيمة الإجراء الصادرة:",
                    fontSize = 11.sp,
                    color = SophisticatedPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = actionPayload,
                    onValueChange = { actionPayload = it },
                    placeholder = { 
                        Text(
                            when(selectedAction) {
                                "TOGGLE_WIFI" -> "اكتب ON أو OFF"
                                "SET_VOLUME" -> "اكتب رقم بين 0 و 100"
                                "SIMULATE_WORK" -> "اكتب WORK_ON أو WORK_OFF"
                                else -> "اكتب النص الذي ينطقه الهاتف بصوت عال"
                            },
                            fontSize = 12.sp, color = SophisticatedSecondaryText
                        ) 
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_payload_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = SophisticatedPrimary,
                        unfocusedBorderColor = SophisticatedOutline,
                        focusedPlaceholderColor = SophisticatedSecondaryText,
                        unfocusedPlaceholderColor = SophisticatedSecondaryText
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // أزرار الحفظ والإلغاء بالتصميم الفاخر
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            if (triggerPhrase.isNotBlank() && actionPayload.isNotBlank()) {
                                onAdd(triggerPhrase, selectedAction, actionPayload)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_save_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedPrimary,
                            contentColor = SophisticatedPrimaryContainer
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("حفظ وتنشيط", color = SophisticatedPrimaryContainer, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, SophisticatedOutline),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء")
                    }
                }
            }
        }
    }
}

fun getReadableActionName(action: String): String {
    return when (action) {
        "SAY_TEXT" -> "مكالمة نصية صوتية"
        "SIMULATE_WORK" -> "التحكم ببيئة ووضع العمل"
        "TOGGLE_WIFI" -> "تحكم الواي فاي والإنترنت"
        "SET_VOLUME" -> "تعديل مستوى الصوت"
        "OPEN_FUN_ZONE" -> "تفعيل وضعية التسلية والملل"
        else -> "إجراء مخصص"
    }
}
